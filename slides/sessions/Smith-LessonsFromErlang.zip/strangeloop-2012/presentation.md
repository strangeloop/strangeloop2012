# Principles of Reliable Systems

## Lessons from Erlang

### Strange Loop 2012

### Garrett Smith, CloudBees

### @gart1

<image src="cb.png" style="margin-top:125px">

---

# Reliability

---

# Quality Wars, Circa 1980s

<img src="malibu.jpg" height="225">

<img src="maxima.jpg" height="250">

---

# Things that break suck

<img src="break.jpg">

---

# Things that keep going arels *awesome*

<img src="reliable.jpg" height="500">

---

# Introducing Erlang

<img src="erlang.jpg">

---

# 99.9999999% Uptime

<img src="axd301.jpg">

---

# Erlang's Roots: PLEX

* Pseudo-parallel, event-driven real-time programming language
* Dedicated for AXE telephone exchanges
* Built in the 1970s by Göran Hemdahl at Ericsson
* Effective, but expensive to use (low level, complex)

---

# A New Language!

* OS independent virtual machine
* Massive fine grained concurrency
* Asynchronous message passing
* Reliability over performance
* Functional pragmatism over purity

---

# Concurrency So Easy...

<img src="caveman.jpg">

---

# The Principles

* Isolation
* Fault detection and recovery
* Separation of concerns
* Back box design
* State management
* Avoid complexity

---

# Isolation

<img src="spock.jpg">

---

# Isolation All Around Us

- Memory
- Threads
- Files
- Disks
- CPU Cores
- Network Interfaces
- Networks
- Racks
- Data Centers

---

# Fault Detection and Recovery

<img src="reboot.png">

---

# Failing

- *Have* to be able to detect failure
- "Fail fast"
- Avoid defensive measures
- Limit the scope of failure

---

# Recovery

## Courtesy of South Park

- Unplug the Internet
- Wait five seconds
- Plug Internet back in

---

# Reboot Fixes Lots of Things

<div style="height:250px">
<img style="position:relative;left:125px;float:left" src="router.jpg">
<img style="position:relative;right:100px;float:right" src="windows.jpg">
</div>

<div>
<img style="position:relative;left:85px;float:left" src="tivo.jpg">
<img style="position:relative;right:100px;float:right" src="iphone.jpg">
</div>

---

# Even an F1 Front Wing!

<img src="wing.jpg">

---

# Separation of Concerns

<img src="tools.jpg">

---

# Small, Focused, Independent

- Easier to reason about
- Easier to test
- Isolation effect - limited scope for change

---

# Black Box Design

<img src="controls.jpg">

---

# Appliances FTW!

- Easy to setup (just plug in?)
- Start button
- Minimal controls
- Reboot to fix

---

# State Management

<img src="scribes.jpg">"

---

# The Thing About State

* Durability -> Recovery
* Replication -> Failover
* Corruption -> Repair
* Consistency -> Synchronization

---

# Four Stages of State Management

<img src="punt.jpg">

---

# Session Failover

## Courtesy Oracle

<img src="session.gif">

---

# Session Punted

<img src="cookiejar.jpg">

---

# Avoid Complexity

<img src="complexity.jpg">

---

# Signs of Complexity

- Dependencies
- Nesting / Hierarchies
- Resource Sharing
- Lots of Code
- Fear

---

# Simple = Reliable

<img src="wedge.jpg" style="margin-top:75px">

---

# Step-by-Step Guide to All This

---

# OS Processes Isolation

- No shared memory
- Communicate via "message passing" (stdio, sockets, pipes)
- Process terminate (i.e. "fault") detection
- Techniques
    - Standard IO "servers"
    - 0MQ (light weight inter process communication via messages)
    - TCP / HTTP

---

# Actors

- No shared memory (semantically)
- Queues to process messages
- Inter thread communication via queue inserts (message passing)
- Direct language support: Scala, Go, Erlang
- Libraries: Kilim (Java), Pykka (Python), Celluloid (Ruby), libcppa (C++)

---

# Fail Fast

- Avoid defensive practices
- Let exceptions propagate as far as possible
- Use assertions and leave them in!
- Exiting the process is not a bad idea

---

# Process Supervision

- Process monitors: runit, launchd
- Standard IO "servers"

---

# Think Small

- Narrowing the scope of an “application”
- Appliance oriented development
- Micro SOA
- Functional style programming (e.g. limit avg functions to < 4 lines)

---

# Invest in Simplicty

- If it's not obvious, work until it becomes obvious
- Take small steps, doing what's clearly the next thing
- Avoid building for the "future"

---

# And In Conclusion...

<img src="conclusion.jpg" style="margin-top:100px">

---

# Twitter FTW!

<div
style="font-size:400%;margin-top:240px;text-align:center;font-family:mono">
@gar1t
</div>


