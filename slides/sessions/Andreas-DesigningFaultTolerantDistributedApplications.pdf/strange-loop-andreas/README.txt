Just threw this together quickly - sorry that it's incomplete.

In short, you'll need a copy of ZooKeeper running locally on port 2181.

Launch the count-based balancing version with scala -cp ordasity.jar ExampleSimple.scala
Launch the load-based balancing version with scala -cp ordasity.jar ExampleSmart.scala

You can create work units for your cluster by running the "create-work-units.txt" commands in the ZooKeeper CLI. You can launch this CLI from your ZooKeeper directory with: `bin/zkCli.sh`

You can find all source code for Ordasity (Apache 2.0 licensed) at http://github.com/boundary/ordasity

If you have any questions, feel free to hit me up on Twitter (@cscotta) or by email (s@boundary.com).

Thanks!

- Scott